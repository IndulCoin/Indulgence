#!/bin/bash
 convert -delay 20 -loop 0 -layers OptimizeFrame *.png new.gif
