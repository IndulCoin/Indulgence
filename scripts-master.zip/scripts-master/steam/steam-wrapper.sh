#!/bin/bash 
export LD_LIBRARY_PATH=~/.local/share/Steam/steam-lib/i386/lib/i386-linux-gnu/:~/.local/share/Steam/steam-lib/amd64/lib/x86_64-linux-gnu/ 
/usr/bin/steam $1
