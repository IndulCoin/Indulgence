#!/bin/bash
path=$(dirname $(readlink -f $0))
